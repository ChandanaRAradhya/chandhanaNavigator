function registervalidate(){

var uname = document.registration.username.value;
var email = document.registration.email.value;
var contactno = document.registration.contactno.value;
var password = document.registration.password.value;
var repassword = document.registration.repassword.value;
var emailformat = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
var mobileno=/^[0-9]$/;

document.getElementById("user").innerHTML="";
document.getElementById("mail").innerHTML="";
document.getElementById("mobile").innerHTML="";
document.getElementById("pass1").innerHTML="";
document.getElementById("pass2").innerHTML=""; 

if (uname==null || uname==""){  
  document.getElementById("user").innerHTML = "Username cant be empty";
  return false;  
}
else if (!emailformat.test(email)) {
	 document.getElementById("mail").innerHTML = "Please provide a valid email address";
     return false;
 }
else if(contactno.length!=10){
     
	document.getElementById("mobile").innerHTML = "Give a valid Mobile number or Mobile no cannot be empty";
	return false;
}
else if(password==null || password=="" || password.length<6){ 
	
	 document.getElementById("pass1").innerHTML = "Password cant be empty or less than 6 characters."; 
	 return false;
}
  else if(repassword==null || repassword==""){ 
  
	 document.getElementById("pass2").innerHTML = " Re-Enter Password cant be empty."; 
	 return false;
}

  else if(password != repassword){ 
 
  document.getElementById("pass2").innerHTML = "Passwords are not matching";
  return false;  
  } 
  else{
  	 document.getElementById("success").innerHTML = "Registered Successfully";
  }
  

}
