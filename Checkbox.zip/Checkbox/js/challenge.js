var data = [
{
    "ProductId": 1,
    "ProductName": "Apple I-Pad Mini",
    "Price": 25699,
    "ImageURL": "images/Apple/01.jpg",
},
{
    "ProductId": 2,
    "ProductName": "Apple I-Phone 4s",
    "Price": 28900,
    "ImageURL": "images/Apple/02.jpg"
},
{
    "ProductId": 3,
    "ProductName": "Apple I-Phone 5s",
    "Price": 38269,
    "ImageURL": "images/Apple/03.jpg"
},
  {
    "ProductId": 4,
    "ProductName": "Apple I-Phone 6sPlus",
    "Price": 73999,
    "ImageURL": "images/Apple/04.jpg"
},
{
    "ProductId": 5,
    "ProductName": "BlackBerry Leap",
    "Price": 21325,
    "ImageURL": "images/BB/10.jpg"
},
{ 
	"ProductId": 6,
    "ProductName": "Nokia X Plus",
    "Price": 4980,
    "ImageURL": "images/Nokia/15.jpg"
},
{ 
    "ProductId": 7,
    "ProductName": "Samsung Battery",
    "Price": 980,
    "ImageURL": "images/memorycard.jpg"
},
{ 
    "ProductId": 8,
    "ProductName": "Selfie Stick",
    "Price": 200,
    "ImageURL": "images/selfie.png"
},
{ 
    "ProductId": 9,
    "ProductName": "Earphone",
    "Price": 690,
    "ImageURL": "images/earphone.jpg"
},
{ 
    "ProductId": 10,
    "ProductName": "Bluetoot-Stereo-Headset",
    "Price": 1020,
    "ImageURL": "images/BluetootStereoHeadset.jpg"
},
{ 
    "ProductId": 11,
    "ProductName": "Lenovo mobile cover",
    "Price": 690,
    "ImageURL": "images/Lenovo mobile cover.jpg"
},
{ 
    "ProductId": 12,
    "ProductName": "mobilechargers",
    "Price": 1190,
    "ImageURL": "images/mobilechargers.jpg"
},
];
//to display products
var products = [];
var cartproducts = [];
/*var i;
var str;*/
function displayProducts(){
	for(var i=0; i<data.length;i++){
// document.getElementById("demo").innerHTML +=  data[i].ProductId ;
/*var images = data[i].ImageURL;
document.getElementById("productsimages").src = images;
document.getElementById("productNames").innerHTML = data[i].ProductName;
document.getElementById("price").innerHTML = data[i].Price;*/
str = '<div class="col-md-4 col-sm-6 col-xs-12 product">';
            str += '<div><figure><img src="' +data[i].ImageURL + '"class="image" />';
            str += '<figcaption>' + data[i].ProductName + '</figcaption></figure>';
            str += '<div class="price">' + "₹" + data[i].Price + '</div>';
            str += '<div class="addtocart">';
            str += '<button class="btn btn-primary btnCart" id='+i+' " onclick = "getClicked(this.id)" >Add to cart</button>';
            str += '</div></div></div>';
            document.getElementById('demo').innerHTML+=str;

}
console.log(str);
}
window.load=displayProducts();

var str1;
var count=1;
 var total=0;
 var tax=0.02;
 var totalamount;
 var discount=0.05;
 var dis_price=0;
var quantity=0;
var threshold=100000;
function getClicked(id){
    var details = id;
    
   str1 = '<div class="col-md-4 col-sm-6 col-xs-12 products">';
 str1 += '<div class="carti"><figure><img src="' + data[details].ImageURL + '" />';
 str1 += '<figcaption>' + data[details].ProductName + '</figcaption></figure>';
 str1 += '<div class="price2">' + data[details].Price + '</div>';
 str1 +='</div></div>';
  document.getElementById("cartdet").innerHTML += str1;
 document.getElementById("cart").innerHTML =count++;
 var price=data[details].Price;

total=total+price;
 document.getElementById("total-cart-amount").innerHTML =total;

 dis_price=total-(total*discount);
 document.getElementById("discount").innerHTML =dis_price.toFixed(2);

taxamount=dis_price*tax;
document.getElementById("tax").innerHTML =taxamount.toFixed(2);
 
  totalamount=dis_price+taxamount;
document.getElementById("total-tax-amount").innerHTML = totalamount.toFixed(2);
/*if(details==details){
    ++quantity;
    var total_quantity=price*quantity;
}
console.log(total_quantity);*/
if(totalamount>threshold){
    var balance=totalamount-threshold;
   /* alert("You have excceded the limit.you have purchased"+ " "+ balance.toFixed(2) +" "+"more");*/
    $('#warning').modal('show');
}
}

//getting the cart details

// Get the modal
var modal = document.getElementById('myModal');

// Get the button that opens the modal
var carbtn = document.getElementById("collapsed");

// Get the <span> element that closes the modal
var span = document.getElementsByClassName("close")[0];



// When the user clicks the button, open the modal 
carbtn.onclick = function() {
    modal.style.display = "block";
}

// When the user clicks on <span> (x), close the modal
span.onclick = function() {
    modal.style.display = "none";
}



   
    


