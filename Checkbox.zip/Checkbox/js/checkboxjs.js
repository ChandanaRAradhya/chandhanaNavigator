function Check(chk)
{
if(document.myform.Check_ctr.checked==true){
for (i = 0; i < chk.length; i++)
chk[i].checked = true ;
}else{

for (i = 0; i < chk.length; i++)
chk[i].checked = false ;
}
}
//window.load=Check(chk);

function Uncheck(chked,chk){
for(var j=0;j<chk.length;j++)
	if(document.myform.check_list[j].checked==false)
	{
		chked.checked = false ;
	}
}

/*window.load=Uncheck(chked);*/